function ClickHere(){
    let showMesseg =prompt('write somthing');
    alert('hello ' + showMesseg)
}