let myForm = document.querySelector('#myform');
let myTodo = document.querySelector('.todo');
let number = 0 ;


myForm.addEventListener('submit', function () {
    if (myTodo.value != '') {
        
        let myList = document.createElement('li');
        myList.innerHTML = myTodo.value;

        let myUl = document.querySelector('#myul');
        myUl.appendChild(myList);
        myTodo.value = '' ;
        number++;
        document.querySelector('.total-count').innerHTML = number;
    } else {
        alert('type  something ...');
    }
})